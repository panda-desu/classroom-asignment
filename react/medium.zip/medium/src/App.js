import React from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import './style/App.css';
import { Article } from './pages/article';

function App() {
  return (
    <>
      <Article />
    </>
  )
}

export default App;
