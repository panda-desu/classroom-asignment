import { SlimNav } from "../components/SlimNav";
export const Article = () => {
  return (
    <>
      <SlimNav />
    </>
  );
};
